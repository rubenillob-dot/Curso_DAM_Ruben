package modelo;

public interface Lavable {
    // por la definición del programa, vamos a definir en el método no solamente que devuelve el precio
    // sino, también modifica el valor de lavado = true. 
    double calcularPrecioLavado();

}
