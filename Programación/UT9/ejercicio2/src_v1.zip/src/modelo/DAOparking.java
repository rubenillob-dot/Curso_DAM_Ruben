package modelo;

import java.util.ArrayList;

/**
 * 
 * void agregarVehiculo(VehiculoAparcado v) // registra un vehículo que entra al
 * parking.
 * 
 * VehiculoAparcado buscarVehiculo(String matricula) / devuelve el vehículo con
 * esa matrícula o null.
 * 
 * double lavarVehiculo(Lavable v) //recibe un Lavable, aplica el lavado y
 * actualiza lavado = true en la instancia de VehiculoAparcado correspondiente;
 * devuelve el precio del lavado.
 * 
 * double calcularIngresosParking() //suma el precio de todos los vehículos que
 * ya han salido.
 * 
 * int cantidadVehiculosAparcados()// devuelve el número de vehículos que están
 * actualmente en el parking (horaSalida == 0 o null).
 */

public class DAOparking {

    private ArrayList<VehiculoAparcado> vehiculos;

    
    public DAOparking() {
        this.vehiculos = new ArrayList<>();
    }

    public void agregarVehiculo(VehiculoAparcado v) {
        vehiculos.add(v);

    }

    public VehiculoAparcado buscarVehiculo(String matricula) {
        for(VehiculoAparcado v: vehiculos){
            if(v.getMatricula().equalsIgnoreCase(matricula)){
                return v; 
            }
        }
        /* 
       return vehiculos.stream()
       .filter(v ->  v.getMatricula().equals(matricula))
       .findFirst()
       .orElse(null);
         */
        return null; 
    }

    /**
     * /recibe un Lavable, aplica el lavado y actualiza lavado = true en la
     * instancia de VehiculoAparcado correspondiente; devuelve el precio del lavado.
     * 

     */
    public double lavarVehiculo(Lavable v) {
        // busca la instancia en el array, para llamar a su método
        // solamente se podrá lavar si aún está dentro del parking
        Lavable lavable = (Lavable) vehiculos.get(vehiculos.indexOf(v));
        if (lavable instanceof VehiculoAparcado va && va.getHoraSalida()==null) {
            return v.calcularPrecioLavado();
            
        }
        // si no está en el parking devolverá cero
        // aquí podríamos lanzar una excepción
        // para asegurar que se conoce el error


        return 0; 
    }
    public double calcularIngresosParking() {
                double acumulado =0; 
        for(VehiculoAparcado v : vehiculos){
            if(v.horaSalida!= null){
                acumulado += v.calcularPrecioParking();
            }
        }
        return acumulado; 
    }
    
    public int cantidadVehiculosAparcados(){
        // es necesario recorrer el array de Vehiculo, para comprobar si la horaSalida = null
        int contador =0; 
        for(VehiculoAparcado v : vehiculos){
            if(v.horaSalida== null){
                contador++;
            }
        }
        return contador; 
    }

    public String mostrarVehiculos(){
        return vehiculos.toString(); 
    }
    

}
