import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

import excepciones.MatriculaInvalida;
import modelo.Coche;
import modelo.Lavable;
import modelo.Moto;
import modelo.VehiculoAparcado;
import modelo.DAOparking;

public class Main {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        DAOparking parking = new DAOparking();
        ArrayList<Lavable> lavables = new ArrayList<>();

        boolean salir = false;

        while (!salir) {
            System.out.println("\n--- Menú Parking ---");
            System.out.println("1. Registrar entrada de vehículo");
            System.out.println("2. Registrar salida de vehículo");
            System.out.println("3. Lavar vehículo");
            System.out.println("4. Mostrar vehículos aparcados");
            System.out.println("5. Mostrar ingresos acumulados");
            System.out.println("6. Salir");
            System.out.print("Opción: ");
            String opcion = sc.nextLine();
            String tipo, matricula;
            int puertas;
            boolean suv;
            switch (opcion) {
                case "1":
                    System.out.print("Tipo (Coche/Moto): ");
                    tipo = sc.nextLine();
                    System.out.print("Matrícula (en formato 1111AAA): ");
                    matricula = sc.nextLine();

                    try {
                        if (tipo.equalsIgnoreCase("Coche")) {
                            System.out.print("Número puertas: ");
                            puertas = introduceUnNumero();

                            System.out.print("¿Es SUV? (true/false): ");
                            suv = sc.nextBoolean();
                            sc.nextLine();
                            Coche coche = new Coche(matricula, puertas, suv);
                            parking.agregarVehiculo(coche);
                            lavables.add(coche);
                            System.out.println("Vehículo ha entrado correctamente.");

                        } else if (tipo.equalsIgnoreCase("Moto")) {
                            System.out.print("Cilindrada: ");
                            int cil = introduceUnNumero();
                            Moto moto = new Moto(matricula, cil);
                            parking.agregarVehiculo(moto);
                            System.out.println("Vehículo ha entrado correctamente.");

                        }else{
                            System.out.println("No es un tipo válido");
                        }

                    } catch (MatriculaInvalida e) {
                        System.out.println(
                                "Error en la lectura de matrícula, vuelve a introducir los datos: ");
                    }
                    break;

                case "2":
                    System.out.print("Matrícula vehículo a registrar salida: ");
                    String salidaMat = sc.nextLine();
                    VehiculoAparcado vSalida = parking.buscarVehiculo(salidaMat);
                    if (vSalida != null && vSalida.getHoraSalida() != null) {

                        vSalida.finalizarAparcamiento();
                        System.out.println("Salida registrada. Precio parking: " + vSalida.calcularPrecioParking());
                    } else {
                        System.out.println("Vehículo no encontrado o ya salió.");
                    }
                    break;

                case "3":
                    System.out.print("Matrícula vehículo a lavar: ");
                    String matLavado = sc.nextLine();
                    boolean encontrado = false;
                    // para poder buscar la matrícula, es necesario convertir a las clases que
                    // tienen
                    // el método getMatricula
                    // por ejemplo a la clase padre
                    for (Lavable l : lavables) {
                        if (l instanceof VehiculoAparcado va && va.getMatricula().equalsIgnoreCase(matLavado)) {
                            double precio = parking.lavarVehiculo(l);
                            System.out.println("Lavado aplicado. Precio lavado: " + precio);
                            encontrado = true;
                            // otra posibilidad es incluir este código en un método que haga return
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("Vehículo no encontrado o no lavable.");
                    }
                    break;

                case "4":
                    System.out.println("--- Vehículos en parking ---");
                    System.out.println(parking.cantidadVehiculosAparcados());
                    System.out.println(parking.mostrarVehiculos());
                    break;

                case "5":
                    System.out.println("Ingresos acumulados de vehículos que ya han salido: " +
                            parking.calcularIngresosParking());
                    break;

                case "6":
                    salir = true;
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        }

        sc.close();
    }

    private static int introduceUnNumero() {

        do {
            try {
                int numero = Integer.parseInt(sc.nextLine());
                return numero;
            } catch (Exception e) {
                System.out.println("No es un número válido, vuelve a intentarlo");
            }

        } while (true);
    }
}