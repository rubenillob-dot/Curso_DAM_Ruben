package modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class DAO {

    private List<Participante> registrados;
    private Set<Participante> asistentesEvento;

    public DAO() {
        this.registrados = new ArrayList<>();
        this.asistentesEvento = new HashSet<>();

        // registros prueba
        cargarRegistros();

    }

    private void cargarRegistros() {
        Participante p;
        for (int i = 0; i <= 10; i++) {
            p = new Participante(("nombre " + i), ("email " + i));
            registrados.add(p);
            if (i % 2 == 0) {
                asistentesEvento.add(p);
            }
        }

    }

    public boolean registrarParticipante(Participante p) {
        // se permiten duplicados
        registrados.add(p);
        return true;
    }

    public String listarRegistrados() {
        if (registrados.isEmpty()) {
            return "No hay participantes registrados";
        }
        return registrados.toString();
    }
    public String listarAsistentes(){
        if (asistentesEvento.isEmpty()) {
            return "No hay participantes con asistencia confirmada";
        }
        return asistentesEvento.toString();
    }

    public Participante buscarParticipanteRegistrado(int idParticipante) {
        // recorrer el arrayList y buscar el id de participante
        for (Participante p : registrados) {
            if (p.getId() == idParticipante) {
                return p;
            }
        }
        return null;

    }

    public boolean registrarAsistencia(Participante p) {
        if (asistentesEvento.add(p)) {
            return true;
        }
        return false;
    }

    public boolean cancelarAsistencia(int idParticipante) {
        // prueba de iterator
        Participante p = null;
        Iterator<Participante> it = asistentesEvento.iterator();
        while (it.hasNext()) {
            p = it.next();
            if (p.getId() == idParticipante) {

                // comprobar si el participante tiene confirmada la asistencia
                for (Participante part : asistentesEvento) {
                    if (part.getId() == idParticipante) {
                        // asistencia confirmada, no se puede borrar
                        return false;
                    }
                } // no se ha encontrado la confirmación de asistencia
                  // borrar el participante de los registrados
                it.remove();

            }
        }

        return false;
    }

    public String mostrarOrdenados() {
        ArrayList<Participante> participantes = new ArrayList<>(asistentesEvento);
        Collections.sort(participantes);
        return participantes.toString(); 
        
    }
}
